import React from 'react'

export const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <p className='text-center'>@Copyrights by VE3</p>
        </footer>
    </div>
  )
}
